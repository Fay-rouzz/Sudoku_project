"""Zero-extra-dependency local website API for Handwritten Sudoku Reader and Solver."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import json, pickle, traceback
import numpy as np
from sudoku_ai.csp import solve
from sudoku_ai.puzzles import generate
from sudoku_ai.integration import run_case
from sudoku_ai.search import repair

ROOT=Path(__file__).resolve().parent
WEB=ROOT/'web'

def clean_grid(grid):
    if not isinstance(grid,list) or len(grid)!=9 or any(not isinstance(row,list) or len(row)!=9 for row in grid):
        raise ValueError('A 9 × 9 grid is required.')
    if any(type(n) is not int or n<0 or n>9 for row in grid for n in row):
        raise ValueError('Every cell must be an integer from 0 to 9.')
    return grid

def demo(seed=7,misreads=1,algorithm='ucs',method='ac3'):
    if not 0<=seed<=100000: raise ValueError('Seed must be between 0 and 100000.')
    if misreads not in (0,1,2):raise ValueError('Misreads must be 0, 1, or 2.')
    with (ROOT/'models'/'nn.pkl').open('rb') as f:model=pickle.load(f)
    data=np.load(ROOT/'data'/'digits.npz')
    case,result=run_case(model,data['x_test'],data['y_test'],seed=seed,misreads=misreads,algorithm=algorithm,method=method)
    return {'source':'Simulated hard recognition mistakes using held-out sklearn Digits images (not photo OCR or MNIST)',
            'input':case['observed'],'original':case['puzzle'],'changed_cells':[divmod(i,9) for i in case['altered']],
            'candidates':{str(i):vals for i,vals in case['candidates'].items()},'result':result}

class Handler(BaseHTTPRequestHandler):
    def reply(self,content,status=200,ctype='application/json'):
        self.send_response(status)
        self.send_header('Content-Type',ctype)
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(content)))
        self.end_headers();self.wfile.write(content)
    def respond(self,obj,status=200):self.reply(json.dumps(obj).encode('utf-8'),status)
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/api/sample':
            self.respond({'grid':generate(7,30)[0]});return
        files={'/':'index.html','/index.html':'index.html','/style.css':'style.css','/app.js':'app.js'}
        if path not in files:self.respond({'error':'Not found'},404);return
        file=WEB/files[path]
        self.reply(file.read_bytes(),ctype={'html':'text/html; charset=utf-8','css':'text/css; charset=utf-8','js':'text/javascript; charset=utf-8'}[file.suffix[1:]])
    def do_POST(self):
        if urlparse(self.path).path not in ('/api/solve','/api/demo','/api/repair'):
            self.respond({'error':'Not found'},404);return
        try:
            size=int(self.headers.get('Content-Length','0'))
            if size>25000:raise ValueError('Request too large.')
            body=json.loads(self.rfile.read(size))
            method=body.get('method','ac3');algorithm=body.get('algorithm','ucs')
            if method not in ('bt','fc','ac3'):raise ValueError('Unknown CSP method.')
            if algorithm not in ('ucs','greedy','astar'):raise ValueError('Unknown search algorithm.')
            if self.path=='/api/solve':
                grid=clean_grid(body.get('grid'))
                self.respond({'result':solve(grid,method=method),'input':grid})
            elif self.path=='/api/demo':
                self.respond(demo(int(body.get('seed',7)),int(body.get('misreads',1)),algorithm,method))
            else:
                grid=clean_grid(body.get('grid'))
                raw=body.get('candidates',{})
                if not isinstance(raw,dict) or len(raw)>81:raise ValueError('Invalid candidate list.')
                candidates={int(i):[(int(d),float(p)) for d,p in pairs] for i,pairs in raw.items()}
                if any(i<0 or i>=81 for i in candidates):raise ValueError('Invalid cell index.')
                self.respond({'result':repair(grid,candidates,algorithm,max_corrections=2,csp_method=method),'input':grid})
        except (ValueError,TypeError,KeyError,FileNotFoundError) as e:self.respond({'error':str(e)},400)
        except Exception:
            traceback.print_exc();self.respond({'error':'Internal processing error. See terminal output.'},500)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8000);args=p.parse_args()
    print(f'Handwritten Sudoku Reader and Solver: http://localhost:{args.port}',flush=True)
    ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
