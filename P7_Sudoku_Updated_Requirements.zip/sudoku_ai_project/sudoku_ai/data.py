"""Reproducible MNIST and small offline Digits datasets.

MNIST keeps the canonical 60,000/10,000 writer-disjoint train/test split,
reserving 10,000 images of the official training partition for validation.
Digit 0 is excluded *after* partitioning because the Sudoku symbols are 1..9.
"""
import argparse
import json
from pathlib import Path
import numpy as np
from sklearn.datasets import load_digits, fetch_openml
from sklearn.model_selection import train_test_split


def load_data(kind='digits', seed=42, cache=None):
    if kind == 'digits':
        dataset = load_digits()
        x = dataset.data.astype('float32') / 16.0
        y = dataset.target.astype(int)
        x_fit, x_rest, y_fit, y_rest = train_test_split(
            x, y, test_size=0.30, random_state=seed, stratify=y)
        x_val, x_test, y_val, y_test = train_test_split(
            x_rest, y_rest, test_size=0.50, random_state=seed, stratify=y_rest)
        source = 'sklearn_digits_8x8_OFFLINE_DEMO'
        split = 'stratified 70/15/15 (sklearn Digits only)'
    elif kind == 'mnist':
        dataset = fetch_openml('mnist_784', version=1, as_frame=False, data_home=cache)
        x = dataset.data.astype('float32') / 255.0
        y = dataset.target.astype(int)
        if len(y) != 70000 or x.shape[1] != 784:
            raise RuntimeError('Expected canonical 70,000-row MNIST (28x28).')
        # OpenML MNIST is ordered: 60K train, 10K official test.
        x_fit, x_val, y_fit, y_val = train_test_split(
            x[:60000], y[:60000], train_size=50000,
            random_state=seed, stratify=y[:60000])
        x_test, y_test = x[60000:], y[60000:]
        source = 'MNIST_28x28_OpenML_784'
        split = 'official MNIST 60K train / 10K untouched test; 50K train + 10K validation from official train'
    else:
        raise ValueError('kind must be digits or mnist')

    def exclude_zero(inputs, labels):
        mask = labels != 0
        return inputs[mask], labels[mask]
    x_fit, y_fit = exclude_zero(x_fit, y_fit)
    x_val, y_val = exclude_zero(x_val, y_val)
    x_test, y_test = exclude_zero(x_test, y_test)
    return (x_fit, x_val, x_test, y_fit, y_val, y_test), source, split


def make_data(out='data', kind='digits', seed=42):
    folder = Path(out)
    folder.mkdir(parents=True, exist_ok=True)
    parts, source, split = load_data(kind, seed)
    np.savez_compressed(folder / 'digits.npz', x_train=parts[0], x_val=parts[1],
                        x_test=parts[2], y_train=parts[3], y_val=parts[4],
                        y_test=parts[5])
    metadata = {
        'source': source, 'seed': seed, 'samples': list(map(len, parts[:3])),
        'feature_count': int(parts[0].shape[1]),
        'normalization': 'pixel/255 for MNIST 28x28; pixel/16 for Digits 8x8',
        'digit_0': 'excluded after splitting', 'split': split,
        'test_untouched': bool(kind == 'mnist'),
        'training_source_verified': True,
    }
    (folder / 'metadata.json').write_text(json.dumps(metadata, indent=2))
    return folder

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--kind', choices=['digits', 'mnist'], default='digits')
    p.add_argument('--out', default='data')
    p.add_argument('--seed', type=int, default=42)
    a = p.parse_args()
    print(make_data(a.out, a.kind, a.seed))
