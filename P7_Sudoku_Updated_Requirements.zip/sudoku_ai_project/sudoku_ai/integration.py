"""Digit samples -> NN probabilities -> Sudoku OCR -> Search -> CSP."""
import numpy as np
from .puzzles import generate
from .search import repair

def build_case(model,images,labels,seed=0,misreads=1,givens=30):
    """Seeded, documented hard OCR corruption for demo and evaluation; never masquerades as organic mistakes."""
    rng=np.random.default_rng(seed);puzzle,answer=generate(seed,givens)
    probs=np.zeros((81,9));indices=np.zeros(81,dtype=int)
    for idx in range(81):
        digit=puzzle[idx//9][idx%9]
        if digit:
            possible=np.flatnonzero(labels==digit);sample=int(rng.choice(possible));indices[idx]=sample
            probabilities=model.predict_proba(images[sample:sample+1])[0]
            probs[idx]=probabilities
    observed=[row[:] for row in puzzle]
    givens_positions=[i for i in range(81) if puzzle[i//9][i%9]]
    rng.shuffle(givens_positions)
    altered=givens_positions[:misreads]
    candidates={}
    # Simulate low-confidence misrecognition using top alternative while retaining true digit as candidate.
    for idx in altered:
        r,c=divmod(idx,9);true=puzzle[r][c]
        conflicts=[puzzle[j//9][j%9] for j in range(81) if j!=idx and j in __import__('sudoku_ai.csp',fromlist=['PEERS']).PEERS[idx] and puzzle[j//9][j%9] not in (0,true)]
        incorrect=int(conflicts[0]) if conflicts else (true%9+1)
        observed[r][c]=incorrect
        original_probability=max(.52,float(probs[idx][incorrect-1]) if incorrect in range(1,10) else .52)
        candidates[idx]=[(incorrect,original_probability),(true,max(.45,float(probs[idx][true-1])))]
    # Other low-confidence givens can also be proposed, but keep search compact
    return {'puzzle':puzzle,'answer':answer,'observed':observed,'candidates':candidates,'altered':altered,'sample_indices':indices.tolist()}

def run_case(model,images,labels,seed=0,misreads=1,algorithm='ucs',method='ac3',givens=30):
    case=build_case(model,images,labels,seed,misreads,givens)
    result=repair(case['observed'],case['candidates'],algorithm,max_corrections=max(2,misreads),csp_method=method)
    result['exact_recovery']=result['status']=='solved' and result['solution']==case['answer']
    return case,result
