"""Trained MLP handwriting classifier and logistic-regression baseline."""
import argparse,json,pickle
from pathlib import Path
import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.linear_model import LogisticRegression
from .eval import classifier_metrics

def train(data='data/digits.npz',out='models',seed=42):
    d=np.load(data);folder=Path(out);folder.mkdir(parents=True,exist_ok=True)
    x,y=d['x_train'],d['y_train']; xt,yt=d['x_test'],d['y_test']
    nn=MLPClassifier(hidden_layer_sizes=(64,),max_iter=200,random_state=seed,early_stopping=True,n_iter_no_change=12)
    base=LogisticRegression(max_iter=500,random_state=seed)
    nn.fit(x,y);base.fit(x,y)
    results={}
    for name,model in [('nn',nn),('logistic_baseline',base)]:
        results[name]=classifier_metrics(model,xt,yt)
        with (folder/(name+'.pkl')).open('wb') as f:pickle.dump(model,f)
    (folder/'metrics.json').write_text(json.dumps(results,indent=2));return results
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',default='data/digits.npz');p.add_argument('--out',default='models');a=p.parse_args();print(json.dumps(train(a.data,a.out),indent=2))
