"""Handwritten Sudoku recognition, probabilistic repair, and constraint solving."""
