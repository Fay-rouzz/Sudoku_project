"""Uniform cost, greedy, and A* over bounded OCR cell corrections."""
import heapq,math
from .csp import solve,PEERS

def conflicts(grid):
    v=[x for row in grid for x in row]
    return [(i,j) for i in range(81) for j in PEERS[i] if i<j and v[i]!=0 and v[i]==v[j]]

def repair(grid,candidates,algorithm='ucs',max_corrections=2,csp_method='ac3'):
    """Candidates: {flat_cell_index: [(digit,probability),...]}; first alternative has cost -log(p_alt/p_read) clipped at 0."""
    if algorithm not in ('ucs','greedy','astar'):raise ValueError('invalid algorithm')
    original=[x for row in grid for x in row]
    opts={}
    for idx,pairs in candidates.items():
        base=max([p for d,p in pairs if d==original[idx]] or [1e-9])
        opts[idx]=[(d,max(0.,math.log(max(base,1e-9)/max(p,1e-9)))) for d,p in pairs if d!=original[idx] and d!=0]
    def mk(state):
        flat=original.copy()
        for idx,d in state:flat[idx]=d
        return [flat[i*9:i*9+9] for i in range(9)]
    def heuristic(state):
        # admissible lower bound: a conflict requires >= one more correction, lower bounded by minimum edit cost
        bad=conflicts(mk(state))
        if not bad:return 0.
        used={i for i,_ in state}; costs=[cost for i,j in bad for idx in (i,j) if idx in opts and idx not in used for digit,cost in opts[idx]]
        return min(costs) if costs else 0.
    heap=[];counter=0;root=()
    heapq.heappush(heap,(0.,counter,0.,root));seen={root};expanded=generated=0;trace=[]
    while heap:
        priority,_,cost,state=heapq.heappop(heap);expanded+=1
        current=mk(state)
        result=solve(current,method=csp_method,limit=1)
        trace.append({'edits':list(map(list,state)),'cost':round(cost,5),'solvable':bool(result['solution'])})
        if result['solution']:
            return {'status':'solved','grid':current,'solution':result['solution'],'edits':[{'cell':[i//9,i%9],'from':original[i],'to':d} for i,d in state], 'cost':cost,'expanded':expanded,'generated':generated,'trace':trace,'csp':result}
        if len(state)>=max_corrections:continue
        chosen={i for i,d in state}
        for i in sorted(opts):
            if i in chosen:continue
            for digit,dc in opts[i]:
                nxt=tuple(sorted((*state,(i,digit))))
                if nxt in seen:continue
                seen.add(nxt);generated+=1;counter+=1
                nc=cost+dc
                score={'ucs':nc,'greedy':heuristic(nxt),'astar':nc+heuristic(nxt)}[algorithm]
                heapq.heappush(heap,(score,counter,nc,nxt))
    return {'status':'unreadable','reason':'No solvable grid within correction budget','expanded':expanded,'generated':generated,'trace':trace}
