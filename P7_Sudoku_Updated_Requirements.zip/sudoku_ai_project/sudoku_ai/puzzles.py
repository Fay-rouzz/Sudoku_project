import random
BASE = [[(r*3+r//3+c)%9+1 for c in range(9)] for r in range(9)]
def generate(seed=0, givens=30):
    """Create a seeded unique-solution Sudoku; givens may exceed requested if uniqueness requires it."""
    rng=random.Random(seed)
    rows=[g*3+r for g in rng.sample(range(3),3) for r in rng.sample(range(3),3)]
    cols=[g*3+c for g in rng.sample(range(3),3) for c in rng.sample(range(3),3)]
    digits=rng.sample(range(1,10),9)
    solution=[[digits[BASE[rows[r]][cols[c]]-1] for c in range(9)] for r in range(9)]
    puzzle=[x[:] for x in solution]
    positions=list(range(81)); rng.shuffle(positions)
    from .csp import solve
    for pos in positions:
        if sum(bool(v) for row in puzzle for v in row)<=givens: break
        r,c=divmod(pos,9); old=puzzle[r][c]; puzzle[r][c]=0
        result=solve(puzzle, method='ac3', limit=2)
        if result['solution_count']!=1: puzzle[r][c]=old
    return puzzle,solution

def flat(grid):return [x for row in grid for x in row]
def show(grid):
    return '\n'.join(' '.join(str(v) if v else '.' for v in row) for row in grid)
