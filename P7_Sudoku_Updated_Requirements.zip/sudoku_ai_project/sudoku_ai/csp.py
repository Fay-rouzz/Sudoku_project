"""Sudoku CSP: independent BT, BT+FC, BT+FC+AC3 modes and counters."""
from collections import deque
PEERS=[]
for p in range(81):
 r,c=divmod(p,9)
 PEERS.append(tuple(sorted(({r*9+j for j in range(9)}|{i*9+c for i in range(9)}|{(r//3*3+i)*9+(c//3*3+j) for i in range(3) for j in range(3)})-{p})))

def ac3(domains, counters=None):
    queue=deque((i,j) for i in range(81) for j in PEERS[i]); revisions=0
    while queue:
        xi,xj=queue.popleft()
        remove={a for a in domains[xi] if not any(a!=b for b in domains[xj])}
        if remove:
            domains[xi]-=remove; revisions+=len(remove)
            if not domains[xi]:
                if counters is not None:counters['arc_revisions']+=revisions
                return False
            queue.extend((xk,xi) for xk in PEERS[xi] if xk!=xj)
    if counters is not None:counters['arc_revisions']+=revisions
    return True

def solve(grid,method='ac3',limit=1):
    if method not in ('bt','fc','ac3'):raise ValueError('method must be bt, fc, or ac3')
    if len(grid)!=9 or any(len(row)!=9 for row in grid):raise ValueError('grid must be 9x9')
    vals=[v for row in grid for v in row]
    if any(not isinstance(v,int) or v<0 or v>9 for v in vals):raise ValueError('digits must be 0..9')
    stats={'assignments':0,'backtracks':0,'arc_revisions':0,'nodes':0}
    for i,v in enumerate(vals):
        if v and any(vals[j]==v for j in PEERS[i] if j<i):
            return {'solution':None,'solution_count':0,**stats}
    domains=[{v} if v else set(range(1,10)) for v in vals]
    if method=='ac3' and not ac3(domains,stats):return {'solution':None,'solution_count':0,**stats}
    found=[]
    def recurse(ds):
        if len(found)>=limit:return
        stats['nodes']+=1
        unassigned=[i for i,d in enumerate(ds) if len(d)>1]
        if not unassigned:
            if all(ds[i]!=ds[j] for i in range(81) for j in PEERS[i] if j>i):
                found.append([[next(iter(ds[r*9+c])) for c in range(9)] for r in range(9)])
            return
        # MRV; deterministic tie-breaking
        i=min(unassigned,key=lambda p:(len(ds[p]),p))
        for v in sorted(ds[i]):
            if any(ds[j]=={v} for j in PEERS[i]):continue
            stats['assignments']+=1
            child=[d.copy() for d in ds];child[i]={v};ok=True
            if method in ('fc','ac3'):
                for j in PEERS[i]:
                    if v in child[j]:
                        if len(child[j])==1:ok=False;break
                        child[j].remove(v)
                if ok and method=='ac3':ok=ac3(child,stats)
            before=len(found)
            if ok:recurse(child)
            if len(found)==before:stats['backtracks']+=1
            if len(found)>=limit:return
    recurse(domains)
    return {'solution':found[0] if found else None,'solution_count':len(found),**stats}
