"""Independent evaluation helpers for classification, Sudoku and correction performance."""
from collections import Counter
import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, log_loss


def expected_calibration_error(y_true, probabilities, classes=tuple(range(1,10)), bins=10):
    """Weighted absolute confidence-accuracy gap in fixed-width confidence bins."""
    probabilities=np.asarray(probabilities,dtype=float)
    y_true=np.asarray(y_true)
    predicted=np.asarray(classes)[probabilities.argmax(axis=1)]
    confidence=probabilities.max(axis=1)
    edges=np.linspace(0,1,bins+1)
    ece=0.
    for i in range(bins):
        mask=(confidence>=edges[i]) & ((confidence<edges[i+1]) if i<bins-1 else (confidence<=edges[i+1]))
        if mask.any():
            ece+=mask.mean()*abs(float((predicted[mask]==y_true[mask]).mean())-float(confidence[mask].mean()))
    return float(ece)


def classifier_metrics(model,x,y):
    y_pred=model.predict(x);prob=model.predict_proba(x)
    return {'accuracy':float(accuracy_score(y,y_pred)),
            'log_loss':float(log_loss(y,prob,labels=model.classes_)),
            'calibration_error_ece10':expected_calibration_error(y,prob,model.classes_),
            'confusion_matrix':confusion_matrix(y,y_pred,labels=list(range(1,10))).tolist()}


def check_solution(grid, givens=None):
    if grid is None or len(grid)!=9 or any(len(r)!=9 for r in grid):return False
    valid=set(range(1,10))
    for r in range(9):
        if set(grid[r])!=valid or {grid[i][r] for i in range(9)}!=valid:return False
    for br in range(0,9,3):
        for bc in range(0,9,3):
            if {grid[r][c] for r in range(br,br+3) for c in range(bc,bc+3)}!=valid:return False
    if givens:
        for r in range(9):
            for c in range(9):
                if givens[r][c] and givens[r][c]!=grid[r][c]:return False
    return True
