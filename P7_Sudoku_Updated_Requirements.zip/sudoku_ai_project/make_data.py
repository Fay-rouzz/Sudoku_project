from sudoku_ai.data import make_data
import argparse
p=argparse.ArgumentParser();p.add_argument('--kind',choices=['digits','mnist'],default='digits');p.add_argument('--seed',type=int,default=42);a=p.parse_args();print(make_data(kind=a.kind,seed=a.seed))
