import json
from pathlib import Path
import numpy as np
import pytest
from sudoku_ai.data import load_data, make_data


def test_digits_reproducible_split():
    a, source_a, split_a = load_data('digits', seed=42)
    b, source_b, split_b = load_data('digits', seed=42)
    assert source_a == source_b and split_a == split_b
    for left, right in zip(a,b):
        assert np.array_equal(left,right)
    assert all(not np.any(y == 0) for y in a[3:])


def test_saved_metadata(tmp_path):
    make_data(out=tmp_path, kind='digits', seed=31)
    metadata=json.loads((tmp_path/'metadata.json').read_text())
    assert metadata['feature_count']==64
    assert metadata['digit_0']=='excluded after splitting'
    assert (tmp_path/'digits.npz').exists()


def test_mnist_official_split_is_retained(monkeypatch):
    # Mock fetch avoids network dependency and tests the official 60k+10k boundary.
    from sudoku_ai import data
    class Dummy:
        data = np.zeros((70000,784), dtype=np.uint8)
        target = np.arange(70000)%10
    monkeypatch.setattr(data, 'fetch_openml', lambda *a,**k:Dummy())
    parts,source,split=data.load_data('mnist', seed=42)
    assert parts[0].shape[1] == 784
    assert sum(map(len, parts[:3])) == 63000
    assert 'official' in split
    assert 'MNIST' in source
