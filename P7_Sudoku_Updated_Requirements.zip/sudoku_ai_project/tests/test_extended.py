"""Additional edge, impossible and known-answer verification tests."""
import pytest
from sudoku_ai.csp import solve
from sudoku_ai.search import repair
from sudoku_ai.puzzles import generate
from sudoku_ai.eval import check_solution, expected_calibration_error
import numpy as np

@pytest.mark.parametrize('mode',['bt','fc','ac3'])
def test_known_sudoku_with_all_modes(mode):
    puzzle,answer=generate(5,45)
    result=solve(puzzle,mode)
    assert result['solution']==answer
    assert check_solution(result['solution'],puzzle)

@pytest.mark.parametrize('mode',['bt','fc','ac3'])
def test_duplicate_givens_have_no_solution(mode):
    puzzle,_=generate(2,45)
    puzzle[0][0]=2;puzzle[0][1]=2
    assert solve(puzzle,mode)['solution'] is None

def test_full_solution_validator_rejects_invalid():
    _,answer=generate(0,45)
    assert check_solution(answer)
    answer[0][0]=answer[0][1]
    assert not check_solution(answer)

def test_impossible_repair_no_candidates():
    puzzle,_=generate(2,45)
    puzzle[0][0]=4;puzzle[0][1]=4
    r=repair(puzzle,{},max_corrections=2)
    assert r['status']=='unreadable' and 'reason' in r

def test_unsupported_search_method():
    with pytest.raises(ValueError):repair([[0]*9 for _ in range(9)],{},algorithm='unknown')

def test_calibration_error_bounded():
    y=np.array([1,2]);p=np.array([[.9,.1],[.1,.9]])
    result=expected_calibration_error(y,p,classes=[1,2])
    assert 0<=result<=1
