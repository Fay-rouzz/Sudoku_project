import pytest
from sudoku_ai.csp import solve,ac3
from sudoku_ai.puzzles import generate
from sudoku_ai.search import repair

@pytest.mark.parametrize('seed',[0,1,2,3,4])
def test_normal_sudoku(seed):
    puzzle,answer=generate(seed,45)
    assert solve(puzzle,'ac3')['solution']==answer

def test_edge_solved_grid():
    _,answer=generate(4,45)
    assert solve(answer,'fc')['solution']==answer

def test_edge_empty_grid_validation():
    assert solve([[0]*9 for _ in range(9)],'ac3')['solution'] is not None

def test_edge_invalid_size():
    with pytest.raises(ValueError):solve([[0]*8 for _ in range(9)])

def test_impossible_duplicate_givens():
    puzzle,_=generate(0,45);puzzle[0][0]=5;puzzle[0][1]=5
    assert solve(puzzle)['solution'] is None

def test_impossible_repair_budget():
    puzzle,_=generate(1,45);puzzle[0][0]=7;puzzle[0][1]=7
    assert repair(puzzle,{},max_corrections=0)['status']=='unreadable'

def test_correction_fixes_conflict():
    puzzle,answer=generate(2,45)
    i=next(i for i in range(81) if puzzle[i//9][i%9])
    from sudoku_ai.csp import PEERS
    j=next(j for j in PEERS[i] if puzzle[j//9][j%9] and puzzle[j//9][j%9]!=puzzle[i//9][i%9])
    true=puzzle[i//9][i%9];wrong=puzzle[j//9][j%9];puzzle[i//9][i%9]=wrong
    result=repair(puzzle,{i:[(wrong,.55),(true,.45)]},max_corrections=1)
    assert result['status']=='solved' and result['solution']==answer
