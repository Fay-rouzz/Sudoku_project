# P7 — Handwritten Sudoku Reader and Solver

End-to-end coursework prototype: handwritten digit classification, probabilistic OCR repair with search, and Sudoku constraint satisfaction.

## What you receive

- `sudoku_ai/data.py`: reproducible dataset and splits
- `sudoku_ai/nn.py`: neural network classifier and logistic regression baseline
- `sudoku_ai/search.py`: UCS, Greedy and A* correction search with metrics and trace
- `sudoku_ai/csp.py`: Backtracking, Forward Checking and AC-3 with counters
- `sudoku_ai/integration.py`: dataset digits -> simulated puzzle OCR -> correction -> solver
- `sudoku_ai/puzzles.py`: uniquely solvable seeded puzzle generator
- `run_demo.py`: complete integrated live demo, console trace and plot
- `experiments.py`: three experimental comparisons, each with five seeds
- `tests/`: normal, edge, impossible and integration tests
- `docs/`: design, data dictionary, report and presentation

## Install and run (Python 3.11 recommended)

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python make_data.py
python train_nn.py
python run_demo.py
python experiments.py
python -m pytest -q
```

Inspect `outputs/demo.png`, `outputs/demo_result.json`, `outputs/experiment_summary.csv`, and `models/metrics.json`.

## True MNIST (coursework-required dataset)

The included **offline runnable demonstration** uses **scikit-learn Digits** (8x8 images), not MNIST. Its true source is explicitly recorded in `data/metadata.json`. To satisfy the **P7 dataset specification**, with internet access run:

```bash
python make_data.py --kind mnist
python train_nn.py
python run_demo.py
python experiments.py
```

This downloads real MNIST images via OpenML (784 features, 28x28), discards zero labels, and trains a 64-hidden-unit MLP. The accompanying datasets and pretrained model in this package are from the *offline* 8x8 fallback and must not be presented as MNIST results. No photographed page extraction is implemented; the source project calls for generated image mosaics, not camera photographs.

## Search algorithm details

The state is a sorted tuple of `(cell_index, replacement_digit)` edits. Start state has no edits. Actions change one previously untouched uncertain given to one of its alternatives. Edge cost is `max(0, log(P(original)/P(alternative)))`; UCS minimizes total edit penalty, Greedy prioritizes a conflict-derived estimate, and A* combines both. Goal test is `CSP solve(corrected_grid) != None`. Maximum corrections defaults to 2. Node expansion and generation counters plus a trace are printed and saved.

**Important:** the A* conflict-based heuristic is intentionally conservative and may become zero; it remains admissible when costs are nonnegative. A sudoku with a valid but *incorrect* uniquely-solvable reading could pass the basic goal check; uniqueness and exact-recovery checking are separate concerns.

## CSP algorithm details

81 variables for 81 cells; digit domains from 1..9; 20 peers per cell (row, column, 3x3 block) and inequality constraints. `bt`: depth-first assignment checking assigned peers; `fc`: additionally removes assigned values from neighbors; `ac3`: initial AC-3 and maintenance after each assignment. MRV selects the smallest remaining domain. `assignments`, `backtracks`, `arc_revisions`, `nodes` are logged.

## Honesty and limitations

- The integrated demo **injects** one or two deliberate low-confidence OCR misreads into a generated puzzle. This is not a claim to handle photographed puzzle pages.
- NN probabilities are calculated on real held-out handwritten digit samples, but the injected error confidence is controlled to make the demo reproducible. `build_case` explicitly documents the intervention.
- `greedy` and `astar` use a conflict lower bound; graph search tie-breaking is deterministic. UCS is the minimum correction-cost algorithm under the bounded candidate space.
- Experiment results are measured on the actual local environment and are not generalized performance claims.
- The full spec asks 100 puzzles per misread level, 25/30/35 givens, and confusion-matrix calibration metrics; these are recommended for a final larger-scale evaluation, beyond the fast five-seed included run.

## Source and generated variables

See `docs/DATA_DICTIONARY.md` for origin and preprocessing rules. Do not interpret injected OCR errors as organic classifier errors.

## Contributions

Before team submission, fill in `docs/CONTRIBUTIONS.md` with each member's genuine work and attach the actual Git log. Do not invent collaborators or Git history.

## Brown-and-cream web application

The project also includes a simple, responsive HTML/CSS/JavaScript interface called **Handwritten Sudoku Reader and Solver** (the exact P7 name). The frontend is served by a Python standard-library HTTP server and calls the existing Python CSP, search and recognition-demo modules.

From the project directory:

```bash
python web_server.py
```

Open **http://localhost:8000** in your browser. Features: editable 9×9 Sudoku board, sample puzzle, CSP method selector, solver statistics, and reproducible correction-search demo with UCS/Greedy/A*. The recognition demo uses sklearn Digits and **deliberately injected** recognition mistakes; it is not real uploaded-image OCR and does not substitute for the assignment's MNIST evaluation.

## Submission audit and standalone HTML

Read **`docs/REQUIREMENTS_AUDIT.md`** before submitting. It maps each of the instructor's 13 shared deliverables to evidence and explicitly identifies remaining work for strict P7 compliance (MNIST run, larger P7 experiments, truthful team contributions). `docs/DEMO_SCRIPT.md` gives a timed 10-minute presentation and 5-minute demonstration plan.

The included `Handwritten_Sudoku_One_File.html` is the **double-click offline interface**: no Python, server or installation. It runs an independent JavaScript Search/CSP demonstration; it **does not run the trained neural network**. Use the Python implementation for the academically required NN results.

Current local verification: `python -m pytest -q` passes 21 tests. Re-run on the submission machine and inspect `models/metrics.json` for the actual offline Digits model; do not mislabel those scores as MNIST.

## Updated evaluation route (November 2026)

`experiments_full.py` provides a P7-specific, five-seed evaluation matrix and figures:

```bash
python experiments_full.py --quick   # verified; 5 seeds, 5 cases per misread level
python experiments_full.py --full    # computationally heavy; 5 seeds x 20 cases = 100 per level
```

It records 0/1/2/3/4 injected misreads; UCS/Greedy/A* nodes, recovery, cost and runtime; BT/FC/AC-3 assignments/backtracks/arc revisions at requested 25/30/35 givens; and NN-guided/no-correction/random baselines. `run_metadata.json` confirms the scope of each run and `summary.csv` reports means and sample standard deviations **across five seed-level averages**. Note that the unique puzzle generator can retain more givens than requested, so actual givens are recorded. `--full` is provided but was **not completed in this packaging session**; its large Sudoku generation workload can take a long time. The verified `outputs/quick/` results are not a substitute for the 100-per-level full run.

The MNIST loader was corrected to preserve the official 60,000/10,000 partition before splitting 50,000/10,000 from the original training portion; zero digits are then filtered from each partition. New unit tests validate this behavior with a mock dataset. No MNIST model was trained in this environment because the dataset host was not reachable. For official MNIST results, first run `python make_data.py --kind mnist`, then `python train_nn.py`; verify `data/metadata.json` and `models/metrics.json` before reporting scores.

`Handwritten_Sudoku_One_File.html` is still a standalone offline browser demo; do not confuse it with the trained NN pipeline. A single local HTML file cannot directly execute the Python `run_demo.py` research pipeline without a runtime/bridge.
