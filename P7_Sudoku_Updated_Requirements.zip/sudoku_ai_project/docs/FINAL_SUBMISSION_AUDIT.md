# P7 submission audit — verified results and outstanding requirements

**Verified offline:** 24 Python tests pass; integrated Python demo previously generated output; `experiments_full.py --quick` completed (five seeds, five cases per misread level; see `outputs/quick/run_metadata.json` and CSV/PNGs). Current offline model is trained on 8x8 sklearn Digits, **not** the specified 28x28 MNIST.

| # | Deliverable | Status in this package |
|---|---|---|
| 1 | Source modules | Included: `sudoku_ai/data.py`, `nn.py`, `search.py`, `csp.py`, `integration.py`, `eval.py`, `tests/` |
| 2 | `make_data.py` | Included, deterministic seed, MNIST download route; official partition logic tested with mock data; online MNIST download **not run** |
| 3 | Data dictionary | Included under `docs/DATA_DICTIONARY.md`, plus `data/metadata.json` |
| 4 | NN and baseline | Included with offline Digits NN/baseline metrics; MNIST training and test results remain **pending** |
| 5 | Search | UCS/Greedy/A* traces, counters, known-case tests included |
| 6 | CSP | BT, FC, AC-3 modes and counters included and tested |
| 7 | Integrated demo | `run_demo.py`, generated output PNG/JSON included |
| 8 | README and pinned deps | Included |
| 9 | Tests | **24 passed** including normal/edge/impossible and dataset-contract checks |
| 10 | Experiments | Three experiments, five-seed quick outputs and mean/std included. Full 100 puzzles/error level **not executed**; available command `python experiments_full.py --full` |
| 11 | Report | `docs/Project_Report.pdf`, existing 3-page coursework report; offline limitations disclosed |
| 12 | Presentation/live demo | Slides and `docs/DEMO_SCRIPT.md` included; actual timed live performance must be delivered by team |
| 13 | Contributions/git log | Honest contribution template and instructions included. Genuine participant statements and repository history must be supplied by the team; no invented log |

## Why there are unfinished items

No external MNIST download was possible in the packaging environment (DNS resolution failed). The 100-puzzles-per-level experiment run was started but exceeded the available execution window after one seed. The included *quick-run* results are genuine, but should not be described as a completed full experiment. University group contribution and Git history cannot be inferred or fabricated.

## Files to use

- `Handwritten_Sudoku_One_File.html`: offline, double-click website, **not a trained-NN browser inference implementation**.
- `python run_demo.py`: true Python module integration, offline model + deliberate corruptions.
- `python experiments_full.py --quick`: fast, already executed; dataset/sample provenance in metadata.
- `python experiments_full.py --full`: required larger P7 comparison, not yet executed.
- `python make_data.py --kind mnist && python train_nn.py`: official dataset training route, requires initial internet download.
- `docs/CONTRIBUTIONS.md`: fill with real contributors; `docs/GIT_LOG_INSTRUCTIONS.md`: export authentic history.
