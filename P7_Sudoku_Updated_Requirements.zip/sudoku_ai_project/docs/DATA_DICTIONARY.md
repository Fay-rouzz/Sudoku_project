# Data dictionary

| Variable | Type | Origin | Definition |
|---|---|---|---|
| x_train/x_val/x_test | float32 [N,64] or [N,784] | real images | flattened handwritten pixels normalized to [0,1] |
| y_train/y_val/y_test | int 1..9 | real labels | digit represented by corresponding image; zeros omitted |
| source | string | script-generated metadata | `sklearn_digits_8x8` or `MNIST_28x28_OpenML` |
| seed | integer | generated | RNG seed for reproducible split and puzzles |
| puzzle | 9x9 ints 0..9 | generated | seeded uniquely solvable Sudoku; 0 means blank |
| answer | 9x9 ints 1..9 | generated | ground-truth completed solution |
| observed | 9x9 ints 0..9 | generated | puzzle with controlled OCR misread injected |
| sample_indices | 81 integers | generated | indices of held-out real digit samples used for probability evaluation |
| candidates | mapping cell -> [(digit,prob)] | model and controlled injection | allowed corrections, includes modified score for injected hard read |
| altered | list of cell indices | generated | locations intentionally corrupted in simulated OCR |
| edits | list of corrected digits | search output | changed cell, original digit, replacement digit |
| cost | float | search output | sum of nonnegative log probability ratios |
| expanded/generated | int | search output | search-state evaluation / discovered-state count |
| assignments/backtracks/arc_revisions | int | solver output | CSP effort / pruning counters |
| exact_recovery | boolean | evaluation | solved grid matches original known solution |

**Offline dataset:** the automatically included model uses sklearn Digits, 8x8, not MNIST. For actual P7 MNIST evaluation call `python make_data.py --kind mnist`, then retrain. Generated Sudoku and injected errors are simulations, not empirically sampled real-world photographed puzzles.
