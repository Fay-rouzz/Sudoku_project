# Genuine Git log for submission

Do not submit a generated or invented git history as though it were a group collaboration record.

From this folder, each actual contributor may initialize and use a repository:

```bash
git init
git add .
git commit -m "Add initial coursework implementation"
# Commit each subsequent *real* change with the actual contributor identity
git log --date=iso --pretty=format:"%h | %an | %ad | %s" > docs/git_log.txt
```

Replace names in `docs/CONTRIBUTIONS.md` only with truthful personal contributions. The download deliberately does not include fabricated commits.
