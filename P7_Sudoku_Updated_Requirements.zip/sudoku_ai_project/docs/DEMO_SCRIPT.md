# Presentation script: 10 minutes + 5-minute live demonstration

## Presentation (10 minutes)
- 0:00–1:00: Problem, input grid, why recognition alone can produce contradictions.
- 1:00–2:15: MNIST data, digit normalization, model and logistic regression baseline. **Name the dataset you actually trained on.**
- 2:15–3:30: NN output probabilities, generated puzzle images, and controlled injection limitation.
- 3:30–5:00: Search state, correction action, nonnegative cost, UCS versus Greedy and A*; show expanded/generated counts.
- 5:00–6:30: CSP 81 variables, inequality constraints, Backtracking, Forward Checking and AC-3; explain domain pruning.
- 6:30–7:30: NN → candidate corrections → search → CSP feedback.
- 7:30–9:00: Three experiments, 5 seeds, mean/std; compare NN ON/OFF without overstating causal performance.
- 9:00–10:00: Limitations, no-solution outcomes, conclusion.

## Live demo (5 minutes)
1. (0:00–1:00) Open the one-click browser interface, load example, run BT, FC, AC-3 and inspect statistics.
2. (1:00–2:15) Run `python run_demo.py --misreads 1 --algorithm ucs --csp ac3`; show observed grid, edit trace, final board.
3. (2:15–3:15) Compare `--algorithm greedy` and `--algorithm astar`; do not promise they always differ.
4. (3:15–4:00) Open experiment summary and chart; explain 5-seed mean and standard deviation.
5. (4:00–5:00) Demonstrate impossible duplicate givens and describe NN ON/OFF experiment; explain that browser-only version simulates recognition.

Prepare cached data and output files in case the demo environment has no internet. Be transparent that the Python and HTML demos are separate implementations.
