# Audit against the 13 shared requirements

This document distinguishes **implemented**, **verified here**, and **requires user action**. It is not a claim that the browser-only HTML satisfies the neural-network coursework alone.

| # | Requirement | Evidence / qualification |
|---|---|---|
| 1 | Named modules | `sudoku_ai/data.py`, `nn.py`, `search.py`, `csp.py`, `integration.py`, `eval.py`, `tests/` |
| 2 | Reproducible data script | `make_data.py --kind mnist --seed 42` fetches MNIST via OpenML; `--kind digits` supplies an **offline example only** |
| 3 | Data dictionary | `docs/DATA_DICTIONARY.md`; distinguishes real pixels/labels from generated Sudoku/corruption |
| 4 | Trained neural network vs baseline | `train_nn.py`, `models/metrics.json` contains measured **offline Digits** results; official MNIST scores require running the MNIST training route |
| 5 | Search & counters | `sudoku_ai/search.py`; UCS/Greedy/A* with expanded/generated and trace; known-answer correction test |
| 6 | CSP & counters | `sudoku_ai/csp.py` BT/FC/AC-3, assignments/backtracks/revisions; switchable and tested |
| 7 | Integrated Python demo | `run_demo.py`, `outputs/demo.png`, `outputs/demo_result.json`, and image mosaic; injected errors disclosed |
| 8 | README & pinned deps | `README.md`, `requirements.txt` |
| 9 | Test cases | `tests/test_project.py` + `tests/test_extended.py` covering normal/edge/impossible; run pytest |
| 10 | Three 5-seed experiments | `experiments.py`, raw and summary CSV and graph. Current quick-run experiments use only **one misread** and **45 givens**, so **not all P7-specific levels** are covered |
| 11 | Report (<=12 pages) | `docs/Project_Report.pdf`; audit page count before submission and label all observed vs simulated results |
| 12 | 10-minute slides + 5-minute live demo | `docs/Project_Presentation.pptx`, `docs/DEMO_SCRIPT.md` are presentation assets; presenter must rehearse timings and use live results |
| 13 | Individual contribution & real git log | `docs/CONTRIBUTIONS.md` is a truthful fill-in form; git history **must come from actual work**, not fabricated attribution |

## Required before claiming complete compliance

1. Download and train on **MNIST** (not scikit-learn Digits). Internet is required for the initial download.
2. Run the P7-specific large experiments (including 100 generated puzzles per error level, levels 0–4; 25/30/35 givens and a calibrated neural classifier). Record failures and full confusion/calibration metrics.
3. Replace placeholders for team names/contributions and provide authentic Git log.
4. Re-run tests on the final machine and check all report figures and source attribution.
5. Do not describe simulated recognition errors as naturally observed OCR failures or photographed page OCR.

## Website vs coursework

`Handwritten_Sudoku_One_File.html` opens offline by double-clicking and is useful for the demo, **but it does not execute Python or a trained NN**. The complete research package lives in Python modules. The two are complementary artifacts.
