const board=document.getElementById('board');
const $=id=>document.getElementById(id);
let grid=Array.from({length:9},()=>Array(9).fill(0));
const cells=[];
for(let r=0;r<9;r++)for(let c=0;c<9;c++){
  const input=document.createElement('input'); input.className='cell'+(r===2||r===5?' block-end':'');
  input.type='text';input.inputMode='numeric';input.maxLength=1;input.setAttribute('aria-label',`Row ${r+1}, column ${c+1}`);
  input.addEventListener('input',()=>{const v=input.value.replace(/[^1-9]/g,'').slice(-1);input.value=v;grid[r][c]=v?Number(v):0;input.classList.remove('given','added','error');$('board-status').textContent='Edited';});
  input.addEventListener('keydown',e=>{const moves={ArrowLeft:[r,c-1],ArrowRight:[r,c+1],ArrowUp:[r-1,c],ArrowDown:[r+1,c]};if(moves[e.key]){e.preventDefault();let [nr,nc]=moves[e.key];if(nr>=0&&nr<9&&nc>=0&&nc<9)cells[nr*9+nc].focus();}if(e.key==='Backspace'||e.key==='Delete'){input.value='';grid[r][c]=0;input.classList.remove('given','added','error');}});
  cells.push(input);board.appendChild(input);
}
function draw(values,kind='given',changed=[]){grid=values.map(row=>row.slice());for(let r=0;r<9;r++)for(let c=0;c<9;c++){let x=cells[r*9+c];x.value=grid[r][c]||'';x.classList.remove('given','added','error');if(grid[r][c])x.classList.add(kind);if(changed.some(p=>p[0]===r&&p[1]===c))x.classList.add('error');}}
async function request(path,body){const res=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});let out=await res.json();if(!res.ok)throw Error(out.error||'Unable to complete request');return out;}
function display(result,mode='solve',source=''){const solved=result.status==='solved'||Boolean(result.solution);$('result-empty').hidden=true;$('result-body').hidden=false;$('result-state').textContent=solved?'Solved':'No solution';$('board-status').textContent=solved?'Solved':'Unsolved';$('expanded').textContent=result.expanded??result.nodes??'—';$('generated').textContent=result.generated??'—';$('assignments').textContent=result.csp?.assignments??result.assignments??'—';$('backtracks').textContent=result.csp?.backtracks??result.backtracks??'—';const div=$('details');div.replaceChildren();const lines=[solved?'A valid Sudoku solution was found.':'No solution was found for this puzzle.'];if(mode==='demo'){lines.push(`Recognition corrections: ${(result.edits||[]).length}`);for(const edit of result.edits||[])lines.push(`Row ${edit.cell[0]+1}, column ${edit.cell[1]+1}: ${edit.from} → ${edit.to}`);lines.push(`Search cost: ${Number(result.cost||0).toFixed(3)}`);lines.push('Recognition notes: '+source);}else{lines.push(`Arc revisions: ${result.arc_revisions??0}`);}for(const line of lines){const p=document.createElement('p');p.textContent=line;div.appendChild(p);}if(solved)draw(result.solution,'added');}
async function run(button,fn){button.disabled=true;let original=button.innerHTML;button.textContent='Working…';try{await fn();}catch(e){$('board-status').textContent='Error';alert(e.message);}finally{button.disabled=false;button.innerHTML=original;}}
$('sample').onclick=()=>run($('sample'),async()=>{let res=await fetch('/api/sample');let data=await res.json();draw(data.grid);$('board-status').textContent='Example loaded';});
$('clear').onclick=()=>{draw(Array.from({length:9},()=>Array(9).fill(0)));$('board-status').textContent='Ready';$('result-empty').hidden=false;$('result-body').hidden=true;$('result-state').textContent='No run yet';};
$('solve').onclick=()=>run($('solve'),async()=>{let data=await request('/api/solve',{grid,method:$('csp').value});display(data.result);});
$('demo').onclick=()=>run($('demo'),async()=>{let data=await request('/api/demo',{seed:7,misreads:Number($('misreads').value),algorithm:$('search').value,method:$('csp').value});draw(data.input,'given',data.changed_cells);display(data.result,'demo',data.source);if(data.result.status==='solved'){// Keep corrected output in the board, and show changes in the results panel.
}});
$('sample').click();
