from sudoku_ai.nn import train
import json
print(json.dumps(train(),indent=2))
