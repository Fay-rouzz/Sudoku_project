import argparse,json,pickle
from pathlib import Path
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sudoku_ai.data import make_data
from sudoku_ai.nn import train
from sudoku_ai.integration import run_case
from sudoku_ai.puzzles import show

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--seed',type=int,default=7);parser.add_argument('--misreads',type=int,default=1);parser.add_argument('--algorithm',choices=['ucs','greedy','astar'],default='ucs');parser.add_argument('--csp',choices=['bt','fc','ac3'],default='ac3');args=parser.parse_args()
    if not Path('data/digits.npz').exists():make_data()
    if not Path('models/nn.pkl').exists():train()
    d=np.load('data/digits.npz')
    with open('models/nn.pkl','rb') as f:model=pickle.load(f)
    case,result=run_case(model,d['x_test'],d['y_test'],seed=args.seed,misreads=args.misreads,algorithm=args.algorithm,method=args.csp)
    print('INPUT PUZZLE:\n'+show(case['observed']))
    print('\nALGORITHM:',args.algorithm,'CSP:',args.csp)
    print('CORRECTIONS:',result.get('edits',[]),'COST:',result.get('cost'))
    print('SEARCH:',{'expanded':result['expanded'],'generated':result['generated']})
    print('TRACE:',json.dumps(result['trace'][:15]))
    print('STATUS:',result['status'],'EXACT_RECOVERY:',result['exact_recovery'])
    if result['status']=='solved':print('SOLVED GRID:\n'+show(result['solution']))
    folder=Path('outputs');folder.mkdir(exist_ok=True)
    with (folder/'demo_result.json').open('w') as f:json.dump({'case':case,'result':result},f,indent=2)
    fig,axs=plt.subplots(1,3,figsize=(12,4))
    for ax,(title,grid) in zip(axs,[('OCR input',case['observed']),('Original puzzle',case['puzzle']),('CSP solution',result.get('solution') or [[0]*9 for _ in range(9)])]):
        ax.set_title(title);ax.set_xlim(0,9);ax.set_ylim(9,0);ax.axis('off')
        for n in range(10):ax.plot([n,n],[0,9],color='black',lw=2 if n%3==0 else .5);ax.plot([0,9],[n,n],color='black',lw=2 if n%3==0 else .5)
        for r in range(9):
            for c in range(9):
                if grid[r][c]:ax.text(c+.5,r+.5,str(grid[r][c]),ha='center',va='center',fontsize=12,color='crimson' if title=='OCR input' and r*9+c in case['altered'] else 'black')
    fig.tight_layout();fig.savefig(folder/'demo.png',dpi=150);plt.close(fig)
    # Build an actual digit-image mosaic from held-out handwriting samples.
    from PIL import Image as PILImage, ImageDraw
    side=int(np.sqrt(d['x_test'].shape[1]));tile=44
    canvas=PILImage.new('RGB',(9*tile+1,9*tile+1),'white');draw=ImageDraw.Draw(canvas)
    for r in range(9):
        for c in range(9):
            digit=case['puzzle'][r][c]
            if not digit:continue
            sample=d['x_test'][case['sample_indices'][r*9+c]].reshape(side,side)
            tile_img=PILImage.fromarray(np.uint8((1-sample)*255)).resize((36,36),resample=PILImage.Resampling.NEAREST).convert('RGB')
            canvas.paste(tile_img,(c*tile+4,r*tile+4))
    for n in range(10):
        draw.line((n*tile,0,n*tile,9*tile),fill='black',width=3 if n%3==0 else 1)
        draw.line((0,n*tile,9*tile,n*tile),fill='black',width=3 if n%3==0 else 1)
    canvas.save(folder/'handwritten_mosaic.png')
    print('Saved outputs/demo.png, outputs/handwritten_mosaic.png, and outputs/demo_result.json')
if __name__=='__main__':main()
