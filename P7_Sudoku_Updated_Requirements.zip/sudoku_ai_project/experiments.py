"""Run 5-seed experiments; CSV/PNG generated from actual executions."""
import csv,pickle,time,json
from pathlib import Path
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sudoku_ai.data import make_data
from sudoku_ai.nn import train
from sudoku_ai.integration import build_case
from sudoku_ai.search import repair
from sudoku_ai.csp import solve
from sudoku_ai.puzzles import generate

def main():
    if not Path('data/digits.npz').exists():make_data()
    if not Path('models/nn.pkl').exists():train()
    d=np.load('data/digits.npz');model=pickle.load(open('models/nn.pkl','rb'))
    out=Path('outputs');out.mkdir(exist_ok=True)
    rows=[]
    for seed in range(5):
        case=build_case(model,d['x_test'],d['y_test'],seed=seed,misreads=1,givens=35)
        for algo in ['ucs','greedy','astar']:
            t=time.perf_counter();r=repair(case['observed'],case['candidates'],algorithm=algo,max_corrections=2)
            rows.append(dict(experiment='search',seed=seed,method=algo,scenario='1 injected misread',metric='nodes_expanded',value=r['expanded']))
            rows.append(dict(experiment='search',seed=seed,method=algo,scenario='1 injected misread',metric='exact_recovery',value=int(r.get('solution')==case['answer'])))
            rows.append(dict(experiment='search',seed=seed,method=algo,scenario='1 injected misread',metric='seconds',value=round(time.perf_counter()-t,5)))
        for method in ['bt','fc','ac3']:
            # 45 givens makes baseline BT feasible; puzzle generators still ensure unique puzzles
            puzzle,_=generate(seed,45)
            t=time.perf_counter();r=solve(puzzle,method)
            for metric in ['assignments','backtracks','arc_revisions']:
                rows.append(dict(experiment='csp',seed=seed,method=method,scenario='45 givens',metric=metric,value=r[metric]))
            rows.append(dict(experiment='csp',seed=seed,method=method,scenario='45 givens',metric='seconds',value=round(time.perf_counter()-t,5)))
        # Integrated predictor comparison: NN scores vs uniform guessing on hard digit; check repair rate
        for predictor in ['nn_guided','no_correction','random_correction']:
            if predictor=='nn_guided':result=repair(case['observed'],case['candidates'],max_corrections=2);success=result.get('solution')==case['answer']
            elif predictor=='no_correction':success=solve(case['observed'])['solution']==case['answer']
            else:
                idx=case['altered'][0];r,c=divmod(idx,9);wrong=[v for v in range(1,10) if v!=case['puzzle'][r][c] and v!=case['observed'][r][c]]
                grid=[row[:] for row in case['observed']];grid[r][c]=wrong[seed%len(wrong)]
                success=solve(grid)['solution']==case['answer']
            rows.append(dict(experiment='predictor',seed=seed,method=predictor,scenario='1 injected misread',metric='exact_recovery',value=int(success)))
    with open(out/'experiments.csv','w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    summary=[]
    for key in sorted(set((r['experiment'],r['method'],r['metric']) for r in rows)):
        values=np.array([float(r['value']) for r in rows if (r['experiment'],r['method'],r['metric'])==key]);summary.append({'experiment':key[0],'method':key[1],'metric':key[2],'runs':len(values),'mean':round(float(values.mean()),5),'std':round(float(values.std(ddof=1)),5)})
    with open(out/'experiment_summary.csv','w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(summary[0]));writer.writeheader();writer.writerows(summary)
    labels=['bt','fc','ac3'];values=[next(s['mean'] for s in summary if s['experiment']=='csp' and s['method']==m and s['metric']=='assignments') for m in labels]
    fig,ax=plt.subplots(figsize=(7,4));ax.bar(labels,values);ax.set_title('CSP search effort (5 seeded runs)');ax.set_ylabel('Mean assignments');fig.tight_layout();fig.savefig(out/'experiment_chart.png',dpi=150);plt.close(fig)
    print(json.dumps(summary,indent=2));print('Saved outputs/experiments.csv, experiment_summary.csv and experiment_chart.png')
if __name__=='__main__':main()
