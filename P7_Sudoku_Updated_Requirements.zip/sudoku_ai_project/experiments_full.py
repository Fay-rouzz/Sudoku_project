"""P7-specific evaluation: all three experiments, raw CSV, mean/std and charts.

Default --quick runs 5 seeds but is for smoke verification only. --full runs
100 generated Sudoku cases PER misread level (0..4), matching P7's scale.
OCR errors are documented, injected mistakes, not natural model errors.
"""
import argparse
import csv
import json
import pickle
import time
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sudoku_ai.integration import build_case
from sudoku_ai.search import repair
from sudoku_ai.csp import solve
from sudoku_ai.puzzles import generate


def run(out='outputs/full', seeds=5, puzzles_per_level=5,
        data_file='data/digits.npz', model_file='models/nn.pkl'):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    d = np.load(data_file)
    with open(model_file, 'rb') as handle:
        model = pickle.load(handle)
    if model.n_features_in_ != d['x_test'].shape[1]:
        raise ValueError('Dataset/model mismatch: retrain model on selected dataset.')
    rows = []
    def record(exp, seed, method, scenario, metric, value):
        rows.append(dict(experiment=exp, seed=seed, method=method,
                         scenario=scenario, metric=metric, value=float(value)))
    for seed in range(seeds):
        for givens in (25, 30, 35):
            puzzle, answer = generate(seed=seed + 927, givens=givens)
            actual_givens = sum(v != 0 for row in puzzle for v in row)
            for method in ('bt', 'fc', 'ac3'):
                start = time.perf_counter()
                result = solve(puzzle, method=method)
                label = f'requested_givens={givens};actual_givens={actual_givens}'
                record('csp', seed, method, label, 'seconds', time.perf_counter()-start)
                record('csp', seed, method, label, 'assignments', result['assignments'])
                record('csp', seed, method, label, 'backtracks', result['backtracks'])
                record('csp', seed, method, label, 'arc_revisions', result['arc_revisions'])
                record('csp', seed, method, label, 'exact_recovery', int(result['solution'] == answer))
        for misreads in range(5):
            # --full=100 puzzles at each error level; per-seed grouping supports statistics.
            for case_index in range(puzzles_per_level):
                case_seed = seed*100003 + case_index + misreads*2003
                case = build_case(model, d['x_test'], d['y_test'],
                                  seed=case_seed, misreads=misreads, givens=35)
                scenario = f'misreads={misreads};case={case_index}'
                for method in ('ucs', 'greedy', 'astar'):
                    start = time.perf_counter()
                    result = repair(case['observed'], case['candidates'], algorithm=method,
                                    max_corrections=4)
                    record('search', seed, method, scenario, 'seconds',time.perf_counter()-start)
                    record('search', seed, method, scenario, 'nodes_expanded', result['expanded'])
                    record('search', seed, method, scenario, 'nodes_generated', result['generated'])
                    record('search', seed, method, scenario, 'correction_cost', result.get('cost', float('nan')))
                    record('search', seed, method, scenario, 'exact_recovery',
                           int(result.get('solution') == case['answer']))
                for predictor in ('nn_guided', 'no_correction', 'random_correction'):
                    if predictor == 'nn_guided':
                        result = repair(case['observed'], case['candidates'], max_corrections=4)
                        success = result.get('solution') == case['answer']
                    elif predictor == 'no_correction':
                        success = solve(case['observed'], 'ac3')['solution'] == case['answer']
                    else:
                        # A seeded random alternative for exactly one incorrect cell.
                        grid = [row[:] for row in case['observed']]
                        if case['altered']:
                            idx = case['altered'][0]
                            r,c = divmod(idx,9)
                            alternatives = [v for v in range(1,10)
                                            if v not in (case['puzzle'][r][c], grid[r][c])]
                            grid[r][c] = alternatives[case_seed % len(alternatives)]
                        success = solve(grid, 'ac3')['solution'] == case['answer']
                    record('predictor', seed, predictor, scenario, 'exact_recovery', int(success))
        print(f'Seed {seed+1}/{seeds} finished',flush=True)
    raw_file=out/'raw.csv'
    with raw_file.open('w',newline='') as f:
        writer=csv.DictWriter(f, fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    # First aggregate cases within each seed so the reported 5-seed standard deviation
    # measures variation between seeds, not pseudoreplication across cases.
    groups={}
    for row in rows:
        scenario_type=row['scenario'].split(';')[0]
        key=(row['experiment'],row['method'],scenario_type,row['metric'],row['seed'])
        groups.setdefault(key,[]).append(row['value'])
    aggregated={}
    for key,values in groups.items():
        aggregated.setdefault(key[:-1],[]).append(float(np.nanmean(values)))
    summary=[]
    for key,values in sorted(aggregated.items()):
        a=np.array(values,dtype=float)
        summary.append(dict(experiment=key[0],method=key[1],scenario=key[2],
                            metric=key[3],seeds=len(a),mean=float(np.nanmean(a)),
                            std=float(np.nanstd(a,ddof=1)) if len(a)>1 else 0.0))
    with (out/'summary.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(summary[0]));writer.writeheader();writer.writerows(summary)
    for experiment,metric,name in [('search','nodes_expanded','search_nodes.png'),
                                   ('csp','assignments','csp_assignments.png'),
                                   ('predictor','exact_recovery','predictor_recovery.png')]:
        selected=[s for s in summary if s['experiment']==experiment and s['metric']==metric]
        labels=[f"{s['method']}\n{s['scenario']}" for s in selected]
        means=[s['mean'] for s in selected]
        errs=[s['std'] for s in selected]
        fig,ax=plt.subplots(figsize=(max(8,len(labels)*1.2),5))
        ax.bar(range(len(labels)),means,yerr=errs,capsize=2)
        ax.set_xticks(range(len(labels)),labels,rotation=45,ha='right')
        ax.set_ylabel(metric + ' (mean ± SD across seeds)')
        ax.set_title(experiment.capitalize() + ' comparison')
        fig.tight_layout()
        fig.savefig(out/name,dpi=150)
        plt.close(fig)
    (out/'run_metadata.json').write_text(json.dumps({
        'seeds':seeds, 'cases_per_seed_per_misread_level':puzzles_per_level,
        'total_cases_per_misread_level':seeds*puzzles_per_level,
        'is_100_cases_per_misread_level':seeds*puzzles_per_level>=100,
        'ocr_errors':'synthetically injected and labelled',
        'feature_count':int(d['x_test'].shape[1]), 'source':str(data_file)
    },indent=2))
    return {'rows':len(rows),'summary_rows':len(summary),'out':str(out)}

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--full',action='store_true',help='100 puzzles/error level: 5 seeds x 20 puzzles/seed')
    p.add_argument('--quick',action='store_true',help='5 seeds x 1 puzzle/seed/error level')
    p.add_argument('--out',default=None)
    p.add_argument('--data',default='data/digits.npz')
    p.add_argument('--model',default='models/nn.pkl')
    args=p.parse_args()
    count=20 if args.full else 1
    output=args.out or ('outputs/full' if args.full else 'outputs/quick')
    print(json.dumps(run(out=output,puzzles_per_level=count,data_file=args.data,model_file=args.model),indent=2))
